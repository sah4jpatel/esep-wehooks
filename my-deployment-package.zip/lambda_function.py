import json
import requests


def lambda_handler(event, context):
    message = "{}".format(event["issue"]["html_url"])
    url = "https://hooks.slack.com/services/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"
    response = requests.post(url)
    return {"message": response.text}
